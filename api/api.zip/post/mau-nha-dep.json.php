<?php

header('Content-Type: application/json');
header('AMP-Access-Control-Allow-Source-Origin: http://localhost');
// header('Access-Control-Allow-Credentials: true');
// header('Access-Control-Allow-Origin: https://theampbook-com.cdn.ampproject.org');
// header('Access-Control-Expose-Headers: AMP-Access-Control-Allow-Source-Origin');
// header('AMP-Access-Control-Allow-Source-Origin: https://theampbook.com');
?>
{"items":[
{"name1":"Mẫu nhà 3 tầng mái thái hiện đại kiểu nhà ống","image1":"https://1.bp.blogspot.com/-yIIcvEEwr-o/YSZggQjCkVI/AAAAAAAABNQ/zi4_TekUhTUHa12SYhePn_prZ695WuD2QCLcBGAsYHQ/s793/56644899_2394513907228151_9204564220446769152_n.jpg","url1":"https://xicop.com/post/mau-nha-3-tang-mai-thai-hien-dai-kieu-nha-ong/",  
"name2":"Mẫu nhà cấp 4 2 phòng ngủ 1 phòng khách thiết kế đẹp giá rẻ","image2":"https://1.bp.blogspot.com/-xneokdUJWFg/YR3i-q9FeyI/AAAAAAAABGE/mrVGQduJUNEcbHDrfpvNXzmRUr1MmN8-ACLcBGAsYHQ/s1469/2.jpg","url2":"https://xicop.com/post/mau-nha-cap-4-2-phong-ngu-1-phong-khach-dep-gia-re/",  
"name3":"Mẫu nhà 2 tầng mái bằng đơn giản mà đẹp hiện đại","image3":"https://1.bp.blogspot.com/-KEdsLvqXSow/YR3B0CmG6oI/AAAAAAAABEg/GRJPOB4bV7ovfe2fcKKhgFaPF4dsvb57gCLcBGAsYHQ/s1753/2.jpg","url3":"https://xicop.com/post/mau-nha-2-tang-mai-bang-don-gian-ma-dep-hien-dai/",  
"name4":"Nhà phố 2 tầng 1 tum đẹp mẫu thiết kế hiện đại","image4":"https://1.bp.blogspot.com/-xfLvslaHBzU/YR0XYgmrk1I/AAAAAAAABCQ/pLPcrMi9tm4Xxf-oiP4NNdegFCsw3_t2ACLcBGAsYHQ/s1742/1.jpg","url4":"https://xicop.com/post/nha-pho-2-tang-1-tum-dep-mau-thiet-ke-hien-dai/",  
"name5":"Biệt thự 2 tầng đơn giản với mẫu nhà biệt thự hai tầng thiết kế đẹp","image5":"https://1.bp.blogspot.com/-0C6etrTBJ64/YR0I0H_WQ0I/AAAAAAAAA_k/111td8JFcWElBXKdYUXn7PaclpIkHKDzgCLcBGAsYHQ/s1361/1.jpg","url5":"https://xicop.com/post/biet-thu-2-tang-don-gian-voi-mau-nha-biet-thu-hai-tang/",  
"name6":"Nhà 3 tầng 100m2 mẫu thiết kế với chi phí xây dựng rẻ","image6":"https://1.bp.blogspot.com/-J79-9hxn4kY/YRz7iVszzbI/AAAAAAAAA_M/i2pe2nUbh1s2sYxTC5jvpfUfke0OwEawACLcBGAsYHQ/s1249/1.jpg","url6":"https://xicop.com/post/nha-3-tang-100m2-mau-thiet-ke-voi-chi-phi-xay-dung-re/ "}


],
"next":"https://xicop.com/api/post/mau-nha-dep.json.php"}
<?php

header('Content-Type: application/json');
header('AMP-Access-Control-Allow-Source-Origin: http://localhost');
// header('Access-Control-Allow-Credentials: true');
// header('Access-Control-Allow-Origin: https://theampbook-com.cdn.ampproject.org');
// header('Access-Control-Expose-Headers: AMP-Access-Control-Allow-Source-Origin');
// header('AMP-Access-Control-Allow-Source-Origin: https://theampbook.com');
?>
{"items":[
{"name":"Mẫu nhà 3 tầng mái thái hiện đại kiểu nhà ống","image":"https://1.bp.blogspot.com/-yIIcvEEwr-o/YSZggQjCkVI/AAAAAAAABNQ/zi4_TekUhTUHa12SYhePn_prZ695WuD2QCLcBGAsYHQ/s793/56644899_2394513907228151_9204564220446769152_n.jpg","url":"https://xicop.com/post/mau-nha-3-tang-mai-thai-hien-dai-kieu-nha-ong/" },  
{"name":"Mẫu nhà cấp 4 2 phòng ngủ 1 phòng khách thiết kế đẹp giá rẻ","image":"https://1.bp.blogspot.com/-xneokdUJWFg/YR3i-q9FeyI/AAAAAAAABGE/mrVGQduJUNEcbHDrfpvNXzmRUr1MmN8-ACLcBGAsYHQ/s1469/2.jpg","url":"https://xicop.com/post/mau-nha-cap-4-2-phong-ngu-1-phong-khach-dep-gia-re/" }

],
"next":"https://dkfree.com/ch7/related-products22.json.php"}
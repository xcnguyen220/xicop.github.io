{
  "items":[    {"results":[     
{"name":"Nhà phố 2 tầng 1 tum đẹp mẫu thiết kế hiện đại","image":"https://1.bp.blogspot.com/-xfLvslaHBzU/YR0XYgmrk1I/AAAAAAAABCQ/pLPcrMi9tm4Xxf-oiP4NNdegFCsw3_t2ACLcBGAsYHQ/s1742/1.jpg","url":"https://xicop.com/post/nha-pho-2-tang-1-tum-dep-mau-thiet-ke-hien-dai/" },  
{"name":"Biệt thự 2 tầng đơn giản với mẫu nhà biệt thự hai tầng thiết kế đẹp","image":"https://1.bp.blogspot.com/-0C6etrTBJ64/YR0I0H_WQ0I/AAAAAAAAA_k/111td8JFcWElBXKdYUXn7PaclpIkHKDzgCLcBGAsYHQ/s1361/1.jpg","url":"https://xicop.com/post/biet-thu-2-tang-don-gian-voi-mau-nha-biet-thu-hai-tang/" },  
{"name":"Nhà 3 tầng 100m2 mẫu thiết kế với chi phí xây dựng rẻ","image":"https://1.bp.blogspot.com/-J79-9hxn4kY/YRz7iVszzbI/AAAAAAAAA_M/i2pe2nUbh1s2sYxTC5jvpfUfke0OwEawACLcBGAsYHQ/s1249/1.jpg","url":"https://xicop.com/post/nha-3-tang-100m2-mau-thiet-ke-voi-chi-phi-xay-dung-re/" }
  ] } ]}
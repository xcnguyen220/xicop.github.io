{
  "items":[    {"results":[     
{"name":"Mẫu nhà 3 tầng mái thái hiện đại kiểu nhà ống","image":"https://1.bp.blogspot.com/-yIIcvEEwr-o/YSZggQjCkVI/AAAAAAAABNQ/zi4_TekUhTUHa12SYhePn_prZ695WuD2QCLcBGAsYHQ/s793/56644899_2394513907228151_9204564220446769152_n.jpg","url":"https://xicop.com/post/mau-nha-3-tang-mai-thai-hien-dai-kieu-nha-ong/" },  
{"name":"Nhà phố 2 tầng 1 tum đẹp mẫu thiết kế hiện đại","image":"https://1.bp.blogspot.com/-xfLvslaHBzU/YR0XYgmrk1I/AAAAAAAABCQ/pLPcrMi9tm4Xxf-oiP4NNdegFCsw3_t2ACLcBGAsYHQ/s1742/1.jpg","url":"https://xicop.com/post/nha-pho-2-tang-1-tum-dep-mau-thiet-ke-hien-dai/" },  
{"name":"Nhà 3 tầng 100m2 mẫu thiết kế với chi phí xây dựng rẻ","image":"https://1.bp.blogspot.com/-J79-9hxn4kY/YRz7iVszzbI/AAAAAAAAA_M/i2pe2nUbh1s2sYxTC5jvpfUfke0OwEawACLcBGAsYHQ/s1249/1.jpg","url":"https://xicop.com/post/nha-3-tang-100m2-mau-thiet-ke-voi-chi-phi-xay-dung-re/" }
  ] } ]}
{
  "items":[    {"results":[     
{"name":"Mẫu nhà 2 tầng mái bằng đơn giản mà đẹp hiện đại","image":"https://1.bp.blogspot.com/-KEdsLvqXSow/YR3B0CmG6oI/AAAAAAAABEg/GRJPOB4bV7ovfe2fcKKhgFaPF4dsvb57gCLcBGAsYHQ/s1753/2.jpg","url":"https://xicop.com/post/mau-nha-2-tang-mai-bang-don-gian-ma-dep-hien-dai/" },  
{"name":"Biệt thự 2 tầng đơn giản với mẫu nhà biệt thự hai tầng thiết kế đẹp","image":"https://1.bp.blogspot.com/-0C6etrTBJ64/YR0I0H_WQ0I/AAAAAAAAA_k/111td8JFcWElBXKdYUXn7PaclpIkHKDzgCLcBGAsYHQ/s1361/1.jpg","url":"https://xicop.com/post/biet-thu-2-tang-don-gian-voi-mau-nha-biet-thu-hai-tang/" },  
{"name":"Mẫu nhà ống 2 tầng mặt tiền 4m thiết kế đẹp có sân thượng","image":"https://1.bp.blogspot.com/-99fA_HEEOoI/YRm5hMsoOdI/AAAAAAAAAoc/xaElLhIXhUYCm1RMwAuHxvuqhdFusl4mgCLcBGAsYHQ/s1500/5.jpg","url":"https://xicop.com/post/mau-nha-ong-2-tang-mat-tien-4m/" }
  ] } ]}
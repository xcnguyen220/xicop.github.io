{
  "items":[    {"results":[     
{"name":"Nội thất nhà phố hiện đại các kiểu thiết kế đẹp số 1","image":"https://1.bp.blogspot.com/-PqZJk_dFtNQ/YRpbFSrMdWI/AAAAAAAAAtM/j1uZIEM4dJs92NgTvySgzs9dfulKIYcBgCLcBGAsYHQ/s1793/1.jpg","url":"https://xicop.com/post/noi-that-nha-pho-hien-dai-cac-kieu-thiet-ke-dep-so-1/" },  
{"name":"Nội thất chung cư đẹp mẫu thiết kế hiện đại với 70m2","image":"https://1.bp.blogspot.com/-1SdKnkehOi4/YRoPoywHI4I/AAAAAAAAArM/fQqT3tiMmGsl3PrVyMqYo2tcRnw4BFMMACLcBGAsYHQ/s1891/4.jpg","url":"https://xicop.com/post/noi-that-chung-cu-dep-mau-thiet-ke-hien-dai-voi-70m2/" },  
{"name":"Thiết kế nội thất hiện đại 1 phong cách mới hợp nhà phố, chung cư","image":"https://1.bp.blogspot.com/-kFZuIT7JnhI/YRoRUva3AOI/AAAAAAAAAr4/ok-JCfKkX54v6dXwt4RZacdq0sXYexYFACLcBGAsYHQ/s1851/1.jpg","url":"https://xicop.com/post/thiet-ke-noi-that-hien-dai-1-phong-cach-moi/" }
  ] } ]}
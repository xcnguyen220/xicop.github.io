{
  "items":[    {"results":[     
{"name":"Mẫu nhà ống cấp 4 đẹp 5×20 mái tôn rất đẹp","image":"https://1.bp.blogspot.com/-ijAMHXKzWk4/YRvXW2dcT4I/AAAAAAAAA8E/WfkP6Ga-gQEPYQL5KxtiDN6G1fcz8Y6cwCLcBGAsYHQ/s1711/1.jpg","url":"https://xicop.com/post/mau-nha-ong-cap-4-dep-5x20-mai-ton-rat-dep/" },  
{"name":"Mẫu nhà phố 3 tầng đẹp các thiết kế hiện đại mặt tiền đẹp","image":"https://1.bp.blogspot.com/-2AL5UbZcjVk/YRvI6A9TBII/AAAAAAAAA6w/1BgHqQzAJbUy-2cw6Hhm8mWbxQxIvynaACLcBGAsYHQ/s1875/1.jpg","url":"https://xicop.com/post/mau-nha-pho-3-tang-dep-cac-thiet-ke-hien-dai-mat-tien/" },  
{"name":"Nhà phố phong cách hiện đại theo thiết kế đẹp 3 tầng","image":"https://1.bp.blogspot.com/-0KjeC_7lNwU/YRu7xdciSXI/AAAAAAAAA5Y/3qSAQA5QpxUCYbLkDWY9_xdNfmCu2tRYACLcBGAsYHQ/s1930/1.jpg","url":"https://xicop.com/post/nha-pho-phong-cach-hien-dai-theo-thiet-ke-dep-3-tang/" }
  ] } ]}